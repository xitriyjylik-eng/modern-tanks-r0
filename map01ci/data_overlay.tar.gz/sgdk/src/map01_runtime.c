#include "map01_runtime.h"
#include "map01_z01_data.h"

static const Map01SectorRuntime *find_sector(u16 worldX, u16 worldY)
{
    u16 sx;
    u16 sy;
    u16 localX;
    u16 localY;
    u16 index;

    if (worldX < MAP01_Z01_WORLD_X0 || worldY < MAP01_Z01_WORLD_Y0) return 0;
    if (worldX >= (MAP01_Z01_WORLD_X0 + MAP01_Z01_SIZE_PX)) return 0;
    if (worldY >= (MAP01_Z01_WORLD_Y0 + MAP01_Z01_SIZE_PX)) return 0;

    sx = worldX / MAP01_SECTOR_SIZE_PX;
    sy = worldY / MAP01_SECTOR_SIZE_PX;

    if (sx < MAP01_Z01_SECTOR_X0 || sx >= (MAP01_Z01_SECTOR_X0 + MAP01_Z01_SECTOR_W)) return 0;
    if (sy < MAP01_Z01_SECTOR_Y0 || sy >= (MAP01_Z01_SECTOR_Y0 + MAP01_Z01_SECTOR_H)) return 0;

    localX = sx - MAP01_Z01_SECTOR_X0;
    localY = sy - MAP01_Z01_SECTOR_Y0;
    index = (localY * MAP01_Z01_SECTOR_W) + localX;
    return &map01_z01_sectors[index];
}

bool MAP01_Z01_hasDataAtWorld(u16 worldX, u16 worldY)
{
    return find_sector(worldX, worldY) != 0;
}

const Map01SectorRuntime *MAP01_Z01_getSectorAtWorld(u16 worldX, u16 worldY)
{
    return find_sector(worldX, worldY);
}

u8 MAP01_Z01_getTerrainAtWorld(u16 worldX, u16 worldY)
{
    const Map01SectorRuntime *sector = find_sector(worldX, worldY);
    u16 cellX;
    u16 cellY;
    u16 cellIndex;

    if (!sector) return MAP01_TERRAIN_NORMAL;

    cellX = (worldX % MAP01_SECTOR_SIZE_PX) / MAP01_LOGIC_CELL_SIZE_PX;
    cellY = (worldY % MAP01_SECTOR_SIZE_PX) / MAP01_LOGIC_CELL_SIZE_PX;
    cellIndex = (cellY * 16u) + cellX;
    return sector->terrain[cellIndex];
}

u8 MAP01_Z01_getCollisionAtWorld(u16 worldX, u16 worldY)
{
    const Map01SectorRuntime *sector = find_sector(worldX, worldY);
    u16 cellX;
    u16 cellY;
    u16 cellIndex;

    /* Until neighbouring zones have authored collision, undefined world is blocked. */
    if (!sector) return MAP01_COLLISION_MAP_BORDER;

    cellX = (worldX % MAP01_SECTOR_SIZE_PX) / MAP01_LOGIC_CELL_SIZE_PX;
    cellY = (worldY % MAP01_SECTOR_SIZE_PX) / MAP01_LOGIC_CELL_SIZE_PX;
    cellIndex = (cellY * 16u) + cellX;
    return sector->collision[cellIndex];
}

bool MAP01_Z01_isBlockedAtWorld(u16 worldX, u16 worldY)
{
    u8 c = MAP01_Z01_getCollisionAtWorld(worldX, worldY);
    return (c == MAP01_COLLISION_HARD_BLOCK) ||
           (c == MAP01_COLLISION_WATER_BLOCK) ||
           (c == MAP01_COLLISION_CLIFF_BLOCK) ||
           (c == MAP01_COLLISION_STRUCTURE_BLOCK) ||
           (c == MAP01_COLLISION_MAP_BORDER);
}

u16 MAP01_Z01_getObjectCount(void)
{
    return map01_z01_object_count;
}

const Map01Object *MAP01_Z01_getObject(u16 runtimeId)
{
    if (runtimeId >= map01_z01_object_count) return 0;
    return &map01_z01_objects[runtimeId];
}

u16 MAP01_Z01_getEventCount(void)
{
    return map01_z01_event_count;
}

const Map01Event *MAP01_Z01_getEvent(u16 runtimeId)
{
    if (runtimeId >= map01_z01_event_count) return 0;
    return &map01_z01_events[runtimeId];
}

u16 MAP01_Z01_getSpawnCount(void)
{
    return map01_z01_spawn_count;
}

const Map01SpawnPoint *MAP01_Z01_getSpawn(u16 runtimeId)
{
    if (runtimeId >= map01_z01_spawn_count) return 0;
    return &map01_z01_spawns[runtimeId];
}

const Map01SpawnPoint *MAP01_Z01_getPlayerStart(void)
{
    u16 i;
    for (i = 0; i < map01_z01_spawn_count; i++)
    {
        const Map01SpawnPoint *spawn = &map01_z01_spawns[i];
        if (spawn->type == MAP01_SPAWN_PLAYER_START && spawn->enabledAtStart)
            return spawn;
    }
    return 0;
}

const u16 *MAP01_Z01_getSectorObjectIds(const Map01SectorRuntime *sector)
{
    if (!sector || !sector->objectCount) return 0;
    return &map01_z01_sector_object_ids[sector->objectOffset];
}

const u16 *MAP01_Z01_getSectorEventIds(const Map01SectorRuntime *sector)
{
    if (!sector || !sector->eventCount) return 0;
    return &map01_z01_sector_event_ids[sector->eventOffset];
}

const u16 *MAP01_Z01_getSectorSpawnIds(const Map01SectorRuntime *sector)
{
    if (!sector || !sector->spawnCount) return 0;
    return &map01_z01_sector_spawn_ids[sector->spawnOffset];
}

#ifndef MAP01_RUNTIME_H
#define MAP01_RUNTIME_H

#include <genesis.h>

#define MAP01_WORLD_WIDTH_PX       1536
#define MAP01_WORLD_HEIGHT_PX      1152
#define MAP01_SECTOR_SIZE_PX       128
#define MAP01_LOGIC_CELL_SIZE_PX   8

#define MAP01_Z01_WORLD_X0         512
#define MAP01_Z01_WORLD_Y0         256
#define MAP01_Z01_SIZE_PX          640
#define MAP01_Z01_SECTOR_X0        4
#define MAP01_Z01_SECTOR_Y0        2
#define MAP01_Z01_SECTOR_W         5
#define MAP01_Z01_SECTOR_H         5

#define MAP01_INVALID_ID           0xFFFFu

typedef enum
{
    MAP01_TERRAIN_NORMAL = 0,
    MAP01_TERRAIN_ROAD = 1,
    MAP01_TERRAIN_FOREST = 2,
    MAP01_TERRAIN_MUD = 3,
    MAP01_TERRAIN_SWAMP = 4,
    MAP01_TERRAIN_SHALLOW_WATER = 5,
    MAP01_TERRAIN_DEEP_WATER = 6,
    MAP01_TERRAIN_BRIDGE = 7,
    MAP01_TERRAIN_ROCK = 8,
    MAP01_TERRAIN_BUILDING = 9,
    MAP01_TERRAIN_RUINS = 10,
    MAP01_TERRAIN_FIELD = 11,
    MAP01_TERRAIN_CRATER_RUBBLE = 12
} Map01TerrainType;

typedef enum
{
    MAP01_COLLISION_FREE = 0,
    MAP01_COLLISION_HARD_BLOCK = 1,
    MAP01_COLLISION_WATER_BLOCK = 2,
    MAP01_COLLISION_CLIFF_BLOCK = 3,
    MAP01_COLLISION_STRUCTURE_BLOCK = 4,
    MAP01_COLLISION_MAP_BORDER = 5,
    MAP01_COLLISION_CONDITIONAL = 6
} Map01CollisionType;

typedef enum
{
    MAP01_OBJECT_BRIDGE = 0,
    MAP01_OBJECT_STATIC_BUILDING,
    MAP01_OBJECT_LANDMARK,
    MAP01_OBJECT_RUIN,
    MAP01_OBJECT_DECOR_LARGE
} Map01ObjectType;

typedef enum
{
    MAP01_EVENT_ZONE_ENTER = 0,
    MAP01_EVENT_DISCOVERY,
    MAP01_EVENT_BRIDGE_CROSS,
    MAP01_EVENT_ZONE_EXIT
} Map01EventType;

typedef enum
{
    MAP01_EVENT_SHAPE_RECT = 0,
    MAP01_EVENT_SHAPE_POLYGON,
    MAP01_EVENT_SHAPE_RADIUS
} Map01EventShape;

typedef enum
{
    MAP01_SPAWN_PLAYER_START = 0,
    MAP01_SPAWN_NPC,
    MAP01_SPAWN_VEHICLE,
    MAP01_SPAWN_ENEMY,
    MAP01_SPAWN_EFFECT
} Map01SpawnType;

typedef enum
{
    MAP01_FACING_NORTH = 0,
    MAP01_FACING_EAST,
    MAP01_FACING_SOUTH,
    MAP01_FACING_WEST
} Map01Facing;

typedef enum
{
    MAP01_HOOK_NONE = 0,
    MAP01_HOOK_ZONE_Z01_VILLAGE_ENTER,
    MAP01_HOOK_DISCOVER_VILLAGE_CENTER,
    MAP01_HOOK_CROSS_NORTH_BRIDGE,
    MAP01_HOOK_DISCOVER_Z01_SOUTH_RUINS,
    MAP01_HOOK_Z01_EXIT_WEST,
    MAP01_HOOK_Z01_EXIT_NORTHWEST,
    MAP01_HOOK_Z01_EXIT_NORTH,
    MAP01_HOOK_Z01_EXIT_EAST,
    MAP01_HOOK_Z01_EXIT_SOUTH
} Map01EventHook;

typedef struct
{
    u16 x0, y0, x1, y1;
} Map01Rect;

typedef struct
{
    u16 x, y;
} Map01Point;

typedef struct
{
    u16 runtimeId;
    u8 type;
    u8 flags;
    Map01Rect bounds;
    Map01Point anchor;
} Map01Object;

typedef struct
{
    u16 runtimeId;
    u8 type;
    u8 shape;
    Map01Rect bounds;
    Map01Point center;
    u16 radius;
    u16 objectRef;
    u16 hook;
    u16 pointOffset;
    u8 pointCount;
    u8 repeatPolicy;
} Map01Event;

typedef struct
{
    u16 runtimeId;
    u8 type;
    u8 facing;
    Map01Point position;
    u8 enabledAtStart;
    u8 reserved;
} Map01SpawnPoint;

typedef struct
{
    u8 worldSectorX;
    u8 worldSectorY;
    const u8 *terrain;
    const u8 *collision;
    u16 objectOffset;
    u8 objectCount;
    u16 eventOffset;
    u8 eventCount;
    u16 spawnOffset;
    u8 spawnCount;
} Map01SectorRuntime;

bool MAP01_Z01_hasDataAtWorld(u16 worldX, u16 worldY);
const Map01SectorRuntime *MAP01_Z01_getSectorAtWorld(u16 worldX, u16 worldY);
u8 MAP01_Z01_getTerrainAtWorld(u16 worldX, u16 worldY);
u8 MAP01_Z01_getCollisionAtWorld(u16 worldX, u16 worldY);
bool MAP01_Z01_isBlockedAtWorld(u16 worldX, u16 worldY);

u16 MAP01_Z01_getObjectCount(void);
const Map01Object *MAP01_Z01_getObject(u16 runtimeId);
u16 MAP01_Z01_getEventCount(void);
const Map01Event *MAP01_Z01_getEvent(u16 runtimeId);
u16 MAP01_Z01_getSpawnCount(void);
const Map01SpawnPoint *MAP01_Z01_getSpawn(u16 runtimeId);
const Map01SpawnPoint *MAP01_Z01_getPlayerStart(void);

const u16 *MAP01_Z01_getSectorObjectIds(const Map01SectorRuntime *sector);
const u16 *MAP01_Z01_getSectorEventIds(const Map01SectorRuntime *sector);
const u16 *MAP01_Z01_getSectorSpawnIds(const Map01SectorRuntime *sector);

#endif

#ifndef MAP01_Z01_DATA_H
#define MAP01_Z01_DATA_H

#include "map01_runtime.h"

extern const u8 map01_z01_terrain[25][256];
extern const u8 map01_z01_collision[25][256];
extern const Map01Object map01_z01_objects[];
extern const Map01Event map01_z01_events[];
extern const Map01Point map01_z01_event_points[];
extern const Map01SpawnPoint map01_z01_spawns[];
extern const Map01SectorRuntime map01_z01_sectors[25];
extern const u16 map01_z01_sector_object_ids[];
extern const u16 map01_z01_sector_event_ids[];
extern const u16 map01_z01_sector_spawn_ids[];

extern const u16 map01_z01_object_count;
extern const u16 map01_z01_event_count;
extern const u16 map01_z01_spawn_count;

#endif
